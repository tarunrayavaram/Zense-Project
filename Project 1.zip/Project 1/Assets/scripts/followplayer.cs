﻿using UnityEngine;

public class followplayer : MonoBehaviour {

    public Transform player;
    public Vector3 offset;//vector3 stores 3 values of type float
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(player.position);// to print "player.position" in console
        transform.position = player.position + offset;
	}
}
