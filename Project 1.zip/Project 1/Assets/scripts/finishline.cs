﻿using UnityEngine;

public class finishline : MonoBehaviour {

    public gamemanager gameManager;

    void OnTriggerEnter()
    {
        gameManager.CompleteLevel();   
    }

}
