﻿using UnityEngine;

public class playercollision : MonoBehaviour
{

    public playermovement movement;
    

    void OnCollisionEnter(Collision collisionInfo)
    {
        //Debug.Log(collisionInfo.collider.name);//collider indicates whether the player is collided or not
                                               //name says the name of the particle player is collided with
       
        if(collisionInfo.collider.tag == "Obstacle")
        {
            //Debug.Log("We hit an Obstacle!");
            movement.enabled = false;
            FindObjectOfType<gamemanager>().EndGame();
            
        }


    }
}