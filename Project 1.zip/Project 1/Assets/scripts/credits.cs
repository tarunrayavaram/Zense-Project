﻿using UnityEngine;

public class credits : MonoBehaviour {

    public void Quit()
    {
        Application.Quit();
    }
}
