﻿using UnityEngine;

public class playermovement : MonoBehaviour {

    public Rigidbody rb;

    public float fowardForce = 2000f;
    public float sidewaysForce = 500f;
	// Use this for initialization
	//void Start () {
        //rb.useGravity = false;
        //rb.AddForce(0, 200, 500);

	//}
	
	// Update is called once per frame
    // we marked this as "Fixed"because we are using it to mess with physics
	void FixedUpdate () {
        rb.AddForce(0, 0, fowardForce*Time.deltaTime);//deltaTime is the time which tells 
                                                      //the no of sec since the computer drew the last frame

        if (Input.GetKey("d"))
        {
            rb.AddForce(sidewaysForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
        }
        if (Input.GetKey("a"))
        {
            rb.AddForce(-sidewaysForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
        }
        if(rb.position.y < -1f)
        {
            FindObjectOfType<gamemanager>().EndGame();
        }

    }
}
